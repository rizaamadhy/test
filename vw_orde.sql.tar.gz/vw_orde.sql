CREATE VIEW "public"."vw_order_history" AS  SELECT k.portalcif,
    concat(k.first_name, ' ', k.middle_name, ' ', k.last_name) AS customer_name,
    se.settlement_account_no AS settlement_account,
    ch.name AS channel_name,
    im.display_name AS fund_manager,
    ut.order_no,
    ut.price_date,
    ut.transaction_date AS trx_date,
    iag.investment_account_no_ava,
    ut.trx_no,
    fp.fund_package_name,
    utt.trx_name AS trx_type,
    ut.net_amount AS amount,
    ut.fee_amount AS fee,
    ut.order_amount AS total,
    ut.trx_status,
    ut.referral_trx_cus_id AS referral_code,
    prd.currency,
    ag2.name AS agent_name,
    utt.trx_code AS trx_type_code
   FROM (((((((((((ut_transactions ut
     LEFT JOIN ut_transaction_type utt ON ((utt.trx_id = ut.transaction_type_id)))
     LEFT JOIN agent ag ON (((ag.code)::text = (ut.referral_trx_cus_id)::text)))
     LEFT JOIN fund_packages fp ON ((fp.fund_package_id = ut.fund_package_ref_id)))
     LEFT JOIN investment_account_grouping iag ON ((iag.id = ut.investement_account_grouping_id)))
     LEFT JOIN kyc k ON ((k.customer_id = ut.kyc_id_id)))
     LEFT JOIN _user u ON ((u.id = k.account_id)))
     LEFT JOIN agent ag2 ON ((ag2.id = u.agent_id)))
     LEFT JOIN channel ch ON ((ch.id = ag2.channel_id)))
     LEFT JOIN ut_products prd ON ((ut.product_id_id = prd.product_id)))
     LEFT JOIN investment_managers im ON ((im.inv_manager_id = prd.investment_managers_id)))
     LEFT JOIN settlement_accounts se ON ((iag.settlement_account_id = se.settlement_account_id)));